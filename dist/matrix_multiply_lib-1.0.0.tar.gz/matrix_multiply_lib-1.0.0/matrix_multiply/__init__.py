from .core import Matrix, matrix_multiply

__version__ = "1.0.0"
__all__ = ["Matrix", "matrix_multiply"]